﻿class Laboratorio12
{
    static void Main(string[] args)
    {
        Console.WriteLine("             LABORATORIO NO.12 - ARREGLOS");
        Console.WriteLine("INSTRUCCIONES: Ingresar diez números en el orden correspondiente. " +
            "\nLos mismos deber ser ingresados en un formato númerico.\n");

        double[] numeros = new double[10];

        for (int i = 0; i < 10; i++)
        {
            Console.WriteLine($"Ingrese el valor del primer número ({i + 1}):");
            numeros[i] = Convert.ToDouble(Console.ReadLine());
        }

        double mayor = numeros[0]; 
        double menor = numeros[0]; 

        for (int j = 1; j < 10; j++)
        {
            if (numeros[j] > mayor)
            {
                mayor = numeros[j];
            }
            if (numeros[j] < menor)
            {
                menor = numeros[j];
            }
        }

        double suma = 0;

        for (int c = 0; c < 10; c++)
        {
            suma = suma + numeros[c];
        }

        double prom = 0;
        prom = suma / 10;

        double sumapar = 0;
        double sumaimpar = 0;

        for (int m = 0; m < 10; m++)
        {
            if (m % 2 == 0)
            {
                sumapar = sumapar + numeros[m];
            }
        }

        for (int p = 0; p < 10; p++)
        {
            if (p % 2 != 0)
            {
                sumaimpar = sumaimpar + numeros[p];
            }
        }

        Console.Clear();

        Console.WriteLine("             RESULTADOS");
        Console.WriteLine("\nEl número mayor del arreglo es: " + mayor);
        Console.WriteLine("El número menor del arreglo es: " + menor);
        Console.WriteLine("La suma de todos los números entre sí es: " + suma);
        Console.WriteLine("El promedio de la suma de todos los números es: " + prom);
        Console.WriteLine("La suma de los números pares del arreglo es: " + sumapar);
        Console.WriteLine("La suma de los números impares del arreglo es: " + sumaimpar);
        Console.WriteLine("Números ingresados en orden de posición (0 a última posición):");
        for (int m = 0; m < 10; m++)
        {
            Console.WriteLine($"    Posición ({m}): {numeros[m]}");
        }
        Console.WriteLine("Números ingresados en orden de posición (última posición a 0):");
        for (int n = 9; n >= 0; n--)
        {
            Console.WriteLine($"    Posición ({n}): {numeros[n]}");
        }
    }
}
