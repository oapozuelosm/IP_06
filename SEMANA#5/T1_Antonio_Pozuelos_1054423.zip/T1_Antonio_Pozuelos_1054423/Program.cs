﻿// See https://aka.ms/new-console-template for more information

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo programa");
        string sNombre, sEdad, sCarrera, sCarne;
        Console.WriteLine("\nIngrese Nombre:");
        sNombre = Console.ReadLine();
        Console.WriteLine("Ingrese Edad:");
        sEdad = Console.ReadLine();
        Console.WriteLine("Ingrese Carrera:");
        sCarrera = Console.ReadLine();
        Console.WriteLine("Ingrese Carne:");
        sCarne = Console.ReadLine();

        Console.WriteLine("\nNombre:" + sNombre);
        Console.WriteLine("Edad:" + sEdad);
        Console.WriteLine("Carrera:" + sCarrera);
        Console.WriteLine("Carné:" + sCarne);

        Console.WriteLine("\nSoy " + sNombre + " tengo " + sEdad + " años y estudio " + sCarrera + ". Mi número de carné es " + sCarne + ".");
        Console.ReadLine();

    }
}
