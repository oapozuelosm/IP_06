﻿class claseMenu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi programa: Gestión de inventario de manufactura en una empresa automotriz.");
        Console.WriteLine("\nSeleccione el carácter del vehículo");
        Console.WriteLine("\nMenú principal:");
        Console.WriteLine("1. Vehículo personal");
        Console.WriteLine("2. Vehículo de carga");
        string opcion;
        opcion = Console.ReadLine();
        if (opcion == "Vehículo personal")
        {
            Console.WriteLine("Usted seleccionó la opción" + opcion + " Vehículo personal");
        }
        else
        {
            Console.WriteLine("Usted seleccionó la opción" + opcion + " Vehículo de carga");
        }
        Console.ReadKey();
    }

    static int stmetodoDummy()
    {
        return 1;
    }
}
