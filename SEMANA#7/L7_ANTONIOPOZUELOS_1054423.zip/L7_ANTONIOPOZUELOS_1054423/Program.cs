﻿class Laboratorio7
{
    static void Main(string[] args)
    {
        //EJERCICIO NO.1
        int n1 = 0;

        Console.WriteLine("'EJERCICIO NO.1'");
        Console.WriteLine("INTRUCCIONES: Dado un número entero, como dato, el ejercicio determinará si el mismo es positivo, negativo o cero");
        Console.WriteLine("\nFavor ingresar un número entero:");
        n1 = Int32.Parse(Console.ReadLine());

        if (n1>0)
        {
            Console.WriteLine("\nRESULTADO: El número ingresado es +POSITIVO.");
        }
        else if (n1<0)
        {
            Console.WriteLine("\nRESULTADO: El número ingresado es -NEGATIVO.");
        }
        else  if (n1==0)
        {
            Console.WriteLine("\nRESULTADO: El número ingresado es CERO.");
        }
        else
        {
            Console.WriteLine("\nEl valor ingresado es inválido.");
        }

        Console.ReadKey();

        //EJERCICIO NO.2
        int dia = 0;

        Console.WriteLine("\n'EJERCICIO NO.2'");
        Console.WriteLine("INTRUCCIONES: Dado un número entero, como dato, el ejercicio determinará a que día de la semana se refiere. \nSiendo 1 el día lunes y 7 el día domingo.");
        Console.WriteLine("\nFavor ingresar un número entero:");
        dia = Int32.Parse(Console.ReadLine());

        if (dia<=0)
        {
            Console.WriteLine("\n ERROR: El número a ingresar debe estar contenido entre 1 y 7.");
        }
        else if (dia>7)
        {
            Console.WriteLine("\nERROR: El número a ingresar debe estar contenido entre 1 y 7.");
        }
        else
        {
        switch (dia)
        {
            case 1:
                Console.WriteLine("\nDÍA: El día ingresado es lunes.");
                break;
            case 2:
                Console.WriteLine("\nDÍA: El día ingresado es martes.");
                break;
            case 3:
                Console.WriteLine("\nDÍA: El día ingresado es miércoles.");
                break;
            case 4:
                Console.WriteLine("\nDÍA: El día ingresado es jueves.");
                break;
            case 5:
                Console.WriteLine("\nDÍA: El día ingresado es viernes.");
                break;
            case 6:
                Console.WriteLine("\nDÍA: El día ingresado es sábado.");
                break;
            case 7:
                Console.WriteLine("\nDÍA: El día ingresado es domingo.");
                break;
        }

        Console.ReadKey();

        }
    }
}
