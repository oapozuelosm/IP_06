﻿class A8_ANTONIO_POZUELOS_S7
{
    static void Main(string[] arg)
    {
        Console.WriteLine("¡Bienvenido!");

        int N1 = 0;
        int N2 = 0;
        int Suma = 0;
        int Multiplicacion = 0;

        Console.WriteLine("\nFavor ingresar un número:");
        N1 = Int32.Parse(Console.ReadLine());

        Console.WriteLine("\nFavor ingresar otro número:");
        N2 = Int32.Parse(Console.ReadLine());

        Suma = N1 + N2;
        Multiplicacion = N1 * N2;

        Console.WriteLine("\nEl total de la suma entre " + N1 + " y " + N2 + " es igual a " + Suma + ".");
        Console.WriteLine("El producto de la multiplicación entre " + N1 + " y " + N2 + " es igual a " + Multiplicacion + ".");

        Console.ReadKey();
    }
}