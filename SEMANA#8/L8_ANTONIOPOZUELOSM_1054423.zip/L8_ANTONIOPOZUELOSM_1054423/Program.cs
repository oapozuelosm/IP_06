﻿class L8_ANTONIOPOZUELOSM_1054423
{
    static void Main(string[] args)
    {
        Console.WriteLine("LABORATORIO NO.8");
        Console.WriteLine("\nNOMBRE: Antonio Pozuelos\nCARNÉ: 1054423\nANTEPENÚLTIMO DÍGITO: Par");
        Console.WriteLine("INSTRUCCIONES: Para los estudiantes con antepenúltimo dígito de carné par, realizar solamente Problema No.1.");

        Console.ReadKey();

        Console.WriteLine("\n\nPROBLEMA NO.1");
        Console.WriteLine("CALCULADORA DE VARIABLES EN FÓRMULAS DE MRUV");
        Console.WriteLine("\nFÓRMULA: Vf = Vo + at");
        Console.WriteLine("DONDE: Vf = Velocidad final, Vo = Velocidad inicial, a = aceleración y t = tiempo.");
        Console.WriteLine("INSTRUCCIONES: A continuación, deberá ingresar tres variables de las cuales conozca su valor. " +
            "En el caso de la variable cuyo valor desee calcular utilizando el programa, simplemente coloque cero como su valor inicial.");

        double a = 0;
        double t = 0;
        double vf = 0;
        double vo = 0;

        Console.Write("\nIngresa la velocidad final (m/s): ");
        vf = double.Parse(Console.ReadLine());

        Console.Write("Ingresa la velocidad inicial (m/s): ");
        vo = double.Parse(Console.ReadLine());

        Console.Write("Ingresa la aceleración (m/s²): ");
        a = double.Parse(Console.ReadLine());

        Console.Write("Ingresa el tiempo (s): ");
        t = double.Parse(Console.ReadLine());

        int contadorvariables = 0;

        if (vf != 0) contadorvariables++;
        if (vo != 0) contadorvariables++;
        if (a != 0) contadorvariables++;
        if (t != 0) contadorvariables++;

        if (contadorvariables != 3)
        {
            Console.WriteLine("\nERROR: Es necesario ingresar exactamente 3 de las 4.");
        }
        else
        {
            double res = 0;

            if (vf == 0)
            {
                res = vo + (a * t);
                Console.WriteLine("\nLa velocidad final es: " + res + "m/s");
            }
            else if (vo == 0)
            {
                res = vf - (a * t);
                Console.WriteLine("\nLa velocidad inicial es: " + res + "m/s");
            }
            else if (a == 0)
            {
                res = (vf - vo) / t;
                Console.WriteLine("\nLa aceleración es: " + res + "m/s²");
            }
            else if (t == 0)
            {
                res = (vf - vo) / a;
                Console.WriteLine("\nEl tiempo es: " + res + "s");
            }
        }

        Console.ReadKey();
        Console.Clear();
    }
}   