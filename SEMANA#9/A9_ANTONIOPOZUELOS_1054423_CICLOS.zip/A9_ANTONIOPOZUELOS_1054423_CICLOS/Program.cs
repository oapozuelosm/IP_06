﻿class ACTIVIDADCICLOS
{
    public static double dCantidad1, dCantidad2, dCantidad3;
    public static string sDenominacion1, sDenominacion2, sDenominacion3;
    public static int contador = 0;
    public static void Main()
    {
        string sCantidad1, sCantidad2, sCantidad3;

        Console.WriteLine("PROGRAMA ACTIVIDAD NO.1 - SEMANA NO.9");

        //CANTIDAD NO.1
        Console.WriteLine("\nIngrese la 1ra. cantidad de dinero: ");
        sCantidad1 = Console.ReadLine();

        while (!double.TryParse(sCantidad1, out dCantidad1))
        {
            Console.WriteLine("Ingrese la 1ra. cantidad en el formato correcto, ejemplo: 0.00");
            sCantidad1 = Console.ReadLine();
        }

        Console.WriteLine("Ingrese la 1ra. denominación: ");
        sDenominacion1 = Console.ReadLine();

        while (sDenominacion1 != "USD" && sDenominacion1 != "GTQ")
        {
            Console.WriteLine("Ingrese la 1ra. denominación como USD o GTQ");
            sDenominacion1 = Console.ReadLine();
        }

        //LLAMADA AL METODO
        calcular(dCantidad1,sDenominacion1);

        //CANTIDAD NO.2
        Console.WriteLine("\nIngrese la 2da. cantidad de dinero: ");
        sCantidad2 = Console.ReadLine();

        while (!double.TryParse(sCantidad2, out dCantidad2))
        {
            Console.WriteLine("Ingrese la 2da. cantidad en el formato correcto, ejemplo: 0.00");
            sCantidad1 = Console.ReadLine();
        }

        Console.WriteLine("Ingrese la 2da. denominación: ");
        sDenominacion2 = Console.ReadLine();

        while (sDenominacion2 != "USD" && sDenominacion2 != "GTQ")
        {
            Console.WriteLine("Ingrese la 2da. denominación como USD o GTQ");
            sDenominacion2 = Console.ReadLine();
        }

        //LLAMADA AL METODO
        calcular(dCantidad2, sDenominacion2);

        //CANTIDAD NO.3
        Console.WriteLine("\nIngrese la 3ra. cantidad de dinero: ");
        sCantidad3 = Console.ReadLine();

        while (!double.TryParse(sCantidad3, out dCantidad3))
        {
            Console.WriteLine("Ingrese la 3ra. cantidad en el formato correcto, ejemplo: 0.00");
            sCantidad1 = Console.ReadLine();
        }

        Console.WriteLine("Ingrese la 3ra. denominación: ");
        sDenominacion3 = Console.ReadLine();

        while (sDenominacion3 != "USD" && sDenominacion3 != "GTQ")
        {
            Console.WriteLine("Ingrese la 3ra. denominación como USD o GTQ");
            sDenominacion3 = Console.ReadLine();
        }

        //LLAMADA AL METODO
        calcular(dCantidad3, sDenominacion3);

        //LLAMADA METODO RESULTADO
        mostrarResultados();
    }

    //DECLARACION DEL METODO TIPO PROCEDIMIENTO POR LA PALABRA VOID
    public static void calcular(double cantidad, string denominacion)
    {
        contador++;

        if (denominacion == "USD")
        {
            cantidad = cantidad * 7.83;
        }

        switch (contador)
        {
            case 1:
                dCantidad1 = cantidad;
                break;

            case 2:
                dCantidad2 = cantidad;
                break;

            case 3:
                dCantidad3 = cantidad;
                break;

            default:
                break;
        }

    }

    //DECLARACION DEL METODO TIPO PROCEDIMIENTO POR LA PALABRA VOID
    public static void mostrarResultados()
    {
        double mayor, medio, menor;

        //MAYOR
        if (dCantidad1 > dCantidad2 && dCantidad1 > dCantidad3)
        {
            mayor = dCantidad1;
        }
        else if (dCantidad2 > dCantidad1 && dCantidad2 > dCantidad3)
        {
            mayor = dCantidad2;
        }
        else
        {
            mayor = dCantidad3;
        }

        //MENOR
        if (dCantidad1 < dCantidad2 && dCantidad1 < dCantidad3)
        {
            menor = dCantidad1;
        }
        else if (dCantidad2 < dCantidad1 && dCantidad2 < dCantidad3)
        {
            menor = dCantidad2;
        }
        else
        {
            menor = dCantidad3;
        }

        //MEDIO
        if (dCantidad1 > menor && dCantidad1 < mayor)
        {
            medio = dCantidad1;
        }
        else if (dCantidad2 > menor && dCantidad2 < mayor)
        {
            medio = dCantidad2;
        }
        else
        {
            medio = dCantidad3;
        }

        string resultado = $"1){menor} GTQ \n2){medio} GTQ \n3){mayor} GTQ ";
        Console.WriteLine("\nResultado:");
        Console.WriteLine(resultado);
        Console.ReadKey();
    }
}