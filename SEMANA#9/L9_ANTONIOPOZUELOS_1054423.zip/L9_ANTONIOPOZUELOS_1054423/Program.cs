﻿class LABORATORIO9
{
    public static double dCantidad, descuento;
    static void Main(string[] args)
    {
        Console.WriteLine("PROGRAMA NO.1 - LABORATORIO NO.9");
        Console.WriteLine("CALCULADORES DE DESCUENTOS");

        string sCantidad;

        Console.WriteLine("\nIngrese el monto de la compra en quetzales (GTQ): ");
        sCantidad = Console.ReadLine();

        while (!double.TryParse(sCantidad, out dCantidad))
        {
            Console.WriteLine("Ingrese el monto en el formato correcto, ejemplo: 0.00");
            sCantidad = Console.ReadLine();
        }
        
        int op = 0;

        Console.WriteLine("\n¿Tiene un código de descuento?\n\nMarque (1) si cuenta con un código.\nMarque (2) si no cuenta con un código.");
        op = Int32.Parse(Console.ReadLine());

        if (op == 1)
        {
            Console.WriteLine("\nIngrese su código de descuento.");
            Console.ReadLine();

            calculardes();
            double montoAPagar = dCantidad - (dCantidad * (descuento + 0.05));
            Console.WriteLine($"\nMonto a pagar: GTQ {montoAPagar}");
        }
        else
        {
            calculardes();
            double montoAPagar = dCantidad - (dCantidad * descuento);
            Console.WriteLine($"\nMonto a pagar: GTQ {montoAPagar}");

        }
    }

    public static void calculardes()
    {
        if (dCantidad < 400)
        {
            descuento = 0;
        }
        else
        {
            if (dCantidad <= 1000)
            {
                descuento = 0.07;
            }
            else
            {
                if (dCantidad <= 5000)
                {
                    descuento = 0.10;
                }
                else
                {
                    if (dCantidad <= 15000)
                    {
                        descuento = 0.15;
                    }
                    else
                    {
                        descuento = 0.25;
                    }
                }
            }
        }
    }
}